/restaurant/menu-items/
/restaurant/menu-items/1
/auth/users/
/auth/token/login/
/auth/token/logout/

Click:
http://127.0.0.1:8000/restaurant/menu-items
http://127.0.0.1:8000/restaurant/menu-items/1
http://127.0.0.1:8000/auth/users/
http://127.0.0.1:8000/auth/token/login/
http://127.0.0.1:8000/auth/token/logout/

